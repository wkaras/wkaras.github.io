ln -s cavl_ex1_h.txt cavl_ex1.h
ln -s cavl_ex1i_c.txt cavl_ex1i.c
ln -s cavl_ex1u_c.txt cavl_ex1u.c
ln -s cavl_ex2_c.txt cavl_ex2.c
ln -s cavl_if_h.txt cavl_if.h
ln -s cavl_impl_h.txt cavl_impl.h
ln -s test_cavl_cpp.txt test_cavl.cpp
